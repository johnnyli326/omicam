<template>
  <div>
		<div class="container mb-5 contact-wrap">
			<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent">
          <li class="breadcrumb-item">
            <router-link to="/">
              HOME
            </router-link>
          </li>
          <li class="breadcrumb-item before active" aria-current="page">
            CONTACT
          </li>
        </ol>
      </nav>
      <section class="section1">
        <h2 class="section-title">SALES CHANNEL</h2>
        <div class="sc-box">
          <div class="cty-box">
            <div class="us"></div>
            <div>US</div>
          </div>
          <div class="channel-box">
            <a class="links"
            href="https://www.amazon.com/Sightour-OmiCam-Wearable-VR-Camera/dp/B07QJBJG44/"
            target="_blank">
              <img src="../assets/images/Contacts/us_amazon.jpg" class="link-img" alt="amazon">
            </a>
            <a class="links"
            href="https://www.newegg.com/Product/Product.aspx?Item=2M1-00DV-00001"
            target="_blank">
              <img src="../assets/images/Contacts/us_newegg.jpg" class="link-img" alt="newegg">
            </a>
          </div>
        </div>
        <div class="sc-box">
          <div class="cty-box">
            <div class="jp"></div>
            <div>JAPAN</div>
          </div>
          <div class="channel-box">
            <a class="links"
            href="https://readyfor.jp/projects/omicam"
            target="_blank">
              <img src="../assets/images/Contacts/jp_readfor.jpg" class="link-img" alt="readfor">
            </a>
            <a class="links"
            href="https://thinkform.thebase.in/"
            target="_blank">
              <img src="../assets/images/Contacts/jp_thinkform.jpg" class="link-img" alt="thinkform">
            </a>
            <a class="links"
            href="https://www.horidashiiti.com/items/11274626"
            target="_blank">
              <img src="../assets/images/Contacts/jp_com.jpg" class="link-img" alt="com">
            </a>
          </div>
        </div>
        <div class="sc-box">
          <div class="cty-box">
            <div class="tw"></div>
            <div>TAIWAN</div>
          </div>
          <div class="channel-box">
            <a class="links"
            href="https://24h.pchome.com.tw/prod/DGCI2O-A9008XKSQ"
            target="_blank">
              <img src="../assets/images/Contacts/tw_pchome.jpg" class="link-img" alt="pchome">
            </a>
            <a class="links"
            href="https://buy3c.in/shop/omicam-vr-camera/"
            target="_blank">
              <img src="../assets/images/Contacts/tw_buy3c.jpg" class="link-img" alt="buy3c">
            </a>
            <br>
            <div class="links">
              <img src="../assets/images/Contacts/tw_igroup.jpg" class="link-img" alt="igroup">
              <div class="text-center">台北市光華新天地2F 88室</div>
            </div>
            <div class="links">
              <img src="../assets/images/Contacts/tw_playcam.jpg" class="link-img" alt="playcam">
              <div class="text-center">台北市光華新天地2F 88室</div>
            </div>
          </div>
        </div>
      </section>
      <section class="section1">
        <h2 class="section-title">CONTACT</h2>
        <div class="sc-box pl-4 mb-0">
          <h4>Customer Service ：service@sightour.com</h4>
        </div>
        <div class="sc-box pl-4">
          <h4>Business Related：sales@sightour.com</h4>
        </div>
        <h2 class="section-title">SOCIAL NETWORK</h2>
        <div class="sc-box end-box">
          <div class="channel-box">
            <a class="links"
            href="https://www.facebook.com/OmiCamUS/"
            target="_blank">
              <img src="../assets/images/Contacts/social_fb.jpg" class="link-img" alt="fb_US">
              <div class="text-center">English</div>
            </a>
            <a class="links"
            href="https://facebook.com/omicamJP/"
            target="_blank">
              <img src="../assets/images/Contacts/social_fb.jpg" class="link-img" alt="fb_JP">
              <div class="text-center">Japanese</div>
            </a>
            <a class="links"
            href="https://www.facebook.com/OMICAMGLOBAL/"
            target="_blank">
              <img src="../assets/images/Contacts/social_fb.jpg" class="link-img" alt="fb_TW">
              <div class="text-center">Chinese Traditional</div>
            </a>
            <br>
            <a class="links"
            href="https://twitter.com/mysight360"
            target="_blank">
              <img src="../assets/images/Contacts/social_twitter.jpg" class="link-img" alt="twitter_US">
              <div class="text-center">English</div>
            </a>
            <a class="links"
            href="https://twitter.com/OmicamJ"
            target="_blank">
              <img src="../assets/images/Contacts/social_twitter.jpg" class="link-img" alt="twitter_JP">
              <div class="text-center">Japanese</div>
            </a>
            <br>
            <a class="links"
            href="https://www.youtube.com/channel/UC_ZWi0Il61IojlC5V1Odojw"
            target="_blank">
              <img src="../assets/images/Contacts/social_youtube.jpg" class="link-img" alt="Youtube">
            </a>
            <br>
            <a class="links"
            href="https://www.facebook.com/groups/209760876430584/"
            target="_blank">
              <img src="../assets/images/Contacts/social_fb.jpg" class="link-img" alt="fb_TW">
              <div class="text-center">Taiwan Group</div>
            </a>
          </div>
        </div>
      </section>
      <section class="section1">
        <h2 class="section-title">ENDED ACTIVITIES</h2>
        <div class="sc-box end-box">
          <div class="channel-box">
            <a class="links"
            href="https://www.kickstarter.com/projects/660471689/mysight360-worlds-first-wearable-vr-camera-for-hik/"
            target="_blank">
              <img src="../assets/images/Contacts/old_kickstarter.jpg" class="link-img" alt="kickstarter">
            </a>
            <a class="links"
            href="https://www.indiegogo.com/projects/mysight360-wearable-vr-camera-for-videos#/"
            target="_blank">
              <img src="../assets/images/Contacts/old_indiegogo.jpg" class="link-img" alt="indiegogo">
            </a>
            <a class="links"
            href="https://www.makuake.com/project/omicam/"
            target="_blank">
              <img src="../assets/images/Contacts/old_makuake.jpg" class="link-img" alt="makuake">
            </a>
          </div>
        </div>
        <div class="sc-box end-box">
          <div class="channel-box">
            <a class="links"
            href="https://cf.machi-ya.jp/project/20181221/04"
            target="_blank">
              <img src="../assets/images/Contacts/old_machi-ya.jpg" class="link-img" alt="machi-ya">
            </a>
            <a class="links"
            href="https://camp-fire.jp/projects/view/110442"
            target="_blank">
              <img src="../assets/images/Contacts/old_campfire.jpg" class="link-img" alt="campfire">
            </a>
            <a class="links"
            href="https://shopping.nikkei.co.jp/projects/omicam"
            target="_blank">
              <img src="../assets/images/Contacts/old_enjine.jpg" class="link-img" alt="enjine">
            </a>
          </div>
        </div>
        <div class="sc-box end-box d-block">
          <div class="channel-box">
            <a class="links"
            href="https://uccu.cool3c.com/projects/423"
            target="_blank">
              <img src="../assets/images/Contacts/old_cool3c.jpg" class="link-img" alt="cool3c">
            </a>
          </div>
        </div>
      </section>
		</div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      channels: [{
				name: '硬式要學',
				URL: 'https://buy3c.in/shop/omicam-vr-camera/',
				imgSrc: require('../assets/images/硬式要學.png'),
			}, {
				name: 'PCHome24h購物',
				URL: 'https://24h.pchome.com.tw/prod/DGCI2O-A9008XKSQ',
				imgSrc: require('../assets/images/PCHOME.png'),
			}, {
				name: 'Kickstarter',
				URL: `https://www.kickstarter.com/projects/660471689/
				mysight360-worlds-first-wearable-vr-camera-for-hik/`,
				imgSrc: require('../assets/images/KICKSTARTER.png'),
			}, {
				name: 'Indiegogo',
				URL: `https://www.indiegogo.com/projects/mysight360-wearable-vr-camera-for-videos#/`,
				imgSrc: require('../assets/images/indiegogo.png'),
			}, {
				name: 'Makuake',
				URL: `https://www.makuake.com/project/omicam/`,
				imgSrc: require('../assets/images/Makuake.png'),
			}, {
				name: 'Machi-ya',
				URL: `https://cf.machi-ya.jp/project/20181221/04`,
				imgSrc: require('../assets/images/machiya.png'),
			}, {
				name: 'Campfire',
				URL: `https://camp-fire.jp/projects/view/110442`,
				imgSrc: require('../assets/images/campfire.png'),
			}]
    };
  },
  created() {
    window.scrollTo(0, 0);
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/mixin";

* {
  text-shadow:0px 0px 8px #1a1a1a;
  font-family:Arial,Helvetica, sans-serif;
}
.contact-wrap {
  padding-top: 50px;
  .breadcrumb {
    border-bottom: 1px solid gray;
    font-size: 28px;
    @include ipad() {
      font-size: 18px;
    }
    .breadcrumb-item {
      &.before::before {
        content: '|';
        color: gray;
      }
    }
  }
  .page-title {
    width: 100%;
    padding: 30px;
    background-color: #f8f9f9;
    border: 1px solid #e9e9e9;
  }
  .news-img {
    box-shadow: 1px 1px 1px 2px gray
  }
  .channel-img {
    width: 250px;
    height: 50px;
  }
  .channel-link {
    word-wrap: break-word;
  }
  .section1 {
    color: white;
    margin: 50px 0;
    .section-title {
      color: #ff9933;
      margin: 50px 0;
    }
    .sc-box {
      display: flex;
      width: 100%;
      height: auto;
      margin-bottom: 50px;
      @include iphone8plus() {
        margin-bottom: 0;
      }
      h4 {
        font-size: 32px;
        @include ipad() {
          width: 100%;
          text-align: left;
          font-size: 24px;
        }
        @include iphone8plus() {
          font-size: 16px;
        }
      }
      &.end-box {
        padding-left: 100px;
        @include iphone8plus() {
          padding-left: 0;
          text-align: center;
        }
      }
      .cty-box {
        display: inline-block;
        padding-top: 30px;
        min-width: 100px;
        width: 100px;
        text-align: center;
        .us {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background-image: url('../assets/images/Contacts/USA.png');
          background-size: cover;
          background-position: left center;
          margin: 0 auto;
        }
        .jp {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background-image: url('../assets/images/Contacts/Japan.png');
          background-size: cover;
          background-position: center center;
          margin: 0 auto;
        }
        .tw {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background-image: url('../assets/images/Contacts/Taiwan.jpg');
          background-size: cover;
          background-position: left center;
          margin: 0 auto;
        }
      }
      .channel-box {
        display: inline-block;
        .links {
          width: 200px;
          display: inline-block;
          margin: 20px;
          color: white;
          .link-img {
            width: 100%;
            border-radius: 15px;
          }
        }
      }
    }
  }
}
</style>
